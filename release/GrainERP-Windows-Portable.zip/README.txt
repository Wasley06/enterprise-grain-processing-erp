Grain ERP Windows Portable

1. Double-click Start-Grain-ERP.bat
2. The app opens in your browser at http://localhost:3210
3. Keep the server window running while using the app.

Requirement: Node.js must be installed on the computer.
