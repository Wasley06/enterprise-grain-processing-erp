@echo off
setlocal
cd /d "%~dp0"
set NODE_ENV=production
set PORT=3210
start "Grain ERP Server" /min node dist\server.cjs
timeout /t 3 /nobreak >nul
start "" "http://localhost:3210"
echo Grain ERP is running at http://localhost:3210
echo Close this window when you are done, then stop the minimized server window.
pause
