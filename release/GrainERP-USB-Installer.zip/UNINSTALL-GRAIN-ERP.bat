@echo off
setlocal
title Grain ERP Uninstaller

set "INSTALL_DIR=%LOCALAPPDATA%\Grain ERP"

if exist "%USERPROFILE%\Desktop\Grain ERP.lnk" del "%USERPROFILE%\Desktop\Grain ERP.lnk"
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Grain ERP.lnk" del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Grain ERP.lnk"
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"

echo.
echo Grain ERP removed from this computer.
echo.
pause
