@echo off
setlocal
title Grain ERP USB Installer

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js is required before installing Grain ERP on this computer.
  echo Download and install Node.js LTS from:
  echo https://nodejs.org
  echo.
  pause
  exit /b 1
)

set "INSTALL_DIR=%LOCALAPPDATA%\Grain ERP"
set "APP_DIR=%INSTALL_DIR%\GrainERP-Windows-Portable"

echo.
echo Installing Grain ERP to:
echo %INSTALL_DIR%
echo.

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%~dp0GrainERP-Windows-Portable.zip' -DestinationPath '%INSTALL_DIR%' -Force"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; $desktop=[Environment]::GetFolderPath('Desktop'); $s=$ws.CreateShortcut($desktop + '\Grain ERP.lnk'); $s.TargetPath='%APP_DIR%\Start-Grain-ERP.bat'; $s.WorkingDirectory='%APP_DIR%'; $s.Save()"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; $start=[Environment]::GetFolderPath('StartMenu') + '\Programs\Grain ERP.lnk'; $s=$ws.CreateShortcut($start); $s.TargetPath='%APP_DIR%\Start-Grain-ERP.bat'; $s.WorkingDirectory='%APP_DIR%'; $s.Save()"

echo.
echo Grain ERP installed successfully.
echo Open it from the Desktop shortcut or Start Menu.
echo.
pause
