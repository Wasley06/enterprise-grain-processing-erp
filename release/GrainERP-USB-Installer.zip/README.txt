Grain ERP USB Installer

Use this package to install Grain ERP on another Windows computer from a USB drive.

Steps:
1. Copy this whole GrainERP-USB-Installer folder to a USB drive.
2. Open the folder on the target computer.
3. Double-click INSTALL-GRAIN-ERP.bat.
4. After installation, open Grain ERP from the Desktop shortcut or Start Menu.

Requirement:
- Node.js LTS must be installed on the target computer.
- If Node.js is missing, the installer will stop and show the Node.js download link.

Why this installer exists:
- This USB installer does not use IExpress or a temporary XP000.TMP folder.
- It avoids the missing Install-Grain-ERP.bat error from the old EXE installer.
